<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHK SALDO VISA</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        #cardForm {
            text-align: center;
            margin-bottom: 20px;
        }
        textarea {
            width: 100%;
            max-width: 600px;
            height: 150px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            margin: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .panel {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .panel div {
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            text-align: center;
            flex: 1 1 calc(25% - 20px); /* Ajusta para 4 colunas */
            min-width: 150px;
        }
        .panel div:nth-child(odd) {
            background-color: #e3f2fd; /* Azul claro */
        }
        .panel div:nth-child(even) {
            background-color: #ffebee; /* Rosa claro */
        }
        h2, h3 {
            text-align: center;
            color: #555;
        }
        #logs {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .log-section {
            width: 100%;
            max-width: 600px;
            background-color: #fff;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            min-height: 150px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .log-section div {
            max-height: 150px;
            overflow-y: auto;
        }
        #copyAprovadas {
            background-color: #007bff;
        }
        #copyAprovadas:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>Testador de Cartões</h1>

    <form id="cardForm">
        <textarea id="cards" name="cards" placeholder="cc|mes|ano|cvv"></textarea><br>
        <button type="submit">Iniciar Testes</button>
        <button type="button" id="clearReprovadas">Limpar Reprovadas</button>
        <button type="button" id="stopTest">Parar Testes</button>
        <button type="button" id="copyAprovadas">Copiar Aprovadas</button>
    </form>

    <div class="panel">
        <div>
            <h3>Carregados</h3>
            <p id="carregados">0</p>
        </div>
        <div>
            <h3>Aprovadas</h3>
            <p id="countAprovados">0</p>
        </div>
        <div>
            <h3>Reprovadas</h3>
            <p id="countReprovados">0</p>
        </div>
        <div>
            <h3>Testadas</h3>
            <p id="countTestadas">0</p>
        </div>
    </div>

    <h2>Logs</h2>
    <div id="logs">
        <div class="log-section">
            <h3>Aprovadas</h3>
            <div id="aprovados"></div>
        </div>
        <div class="log-section">
            <h3>Reprovadas</h3>
            <div id="reprovados"></div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            let isTesting = true;

            // Iniciar os testes ao submeter o formulário
            $('#cardForm').on('submit', function(e) {
                e.preventDefault();
                const cards = $('#cards').val().split('\n');
                $('#carregados').text(cards.length);

                // Enviar os dados para o servidor
                $.ajax({
                    url: '/start',
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        // Remover a primeira linha da textarea após o envio
                        let updatedCards = $('#cards').val().split('\n');
                        updatedCards.shift(); // Remove a primeira linha
                        $('#cards').val(updatedCards.join('\n'));
                    }
                });
            });

            // Limpar reprovados
            $('#clearReprovadas').on('click', function() {
                $('#reprovados').html('');
                $('#countReprovados').text(0);
            });

            // Parar os testes
            $('#stopTest').on('click', function() {
                isTesting = false;
            });

            // Copiar aprovadas
            $('#copyAprovadas').on('click', function() {
                const aprovadas = $('#aprovados').text();
                const tempElement = $('<textarea>');
                $('body').append(tempElement);
                tempElement.val(aprovadas).select();
                document.execCommand('copy');
                tempElement.remove();
                alert('Aprovadas copiadas para a área de transferência!');
            });

            // Atualizar logs e status a cada 5 segundos
            function fetchLogs() {
                if (!isTesting) return;

                $.ajax({
                    url: '/logs',
                    success: function(data) {
                        $('#aprovados').html(data.aprovados.join('<br>'));
                        $('#reprovados').html(data.reprovados.join('<br>'));
                        $('#countAprovados').text(data.aprovados.length);
                        $('#countReprovados').text(data.reprovados.length);
                        $('#countTestadas').text(data.aprovados.length + data.reprovados.length);
                    }
                });
            }

            setInterval(fetchLogs, 5000);
        });
    </script>
</body>
</html>